module.exports = new Map();
/**

{
    // ["numero de celular"]: "último dni consultado"
    ["+54987654321"]: "78654321",
    ["+54977123456"]: "76548123",
}

 */
