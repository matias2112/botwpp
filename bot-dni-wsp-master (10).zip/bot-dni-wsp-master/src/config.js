module.exports = {
  startCommands: ["hola", "Hola"],
};
